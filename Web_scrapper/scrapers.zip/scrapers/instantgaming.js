// ============================================================
//  scrapers/instantgaming.js — v5 API pública
// ============================================================

import axios from 'axios';

const BASE_URL = 'https://www.instant-gaming.com';

const HEADERS = {
  'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept':          'application/json',
  'Accept-Language': 'es-ES,es;q=0.9',
  'Referer':         'https://www.instant-gaming.com/',
};

const DEMO_PRICES = {
  'cyberpunk 2077':        { price: 8.99,  region: 'Europa' },
  'the witcher 3':         { price: 5.99,  region: 'Europa' },
  'elden ring':            { price: 26.99, region: 'Europa' },
  'red dead redemption 2': { price: 16.99, region: 'Europa' },
  "baldur's gate 3":       { price: 41.99, region: 'Europa' },
  'starfield':             { price: 22.99, region: 'Europa' },
  'hogwarts legacy':       { price: 19.99, region: 'Europa' },
  'grand theft auto v':    { price: 9.99,  region: 'Europa' },
  'resident evil 4':       { price: 16.99, region: 'Europa' },
  'dark souls iii':        { price: 9.49,  region: 'Europa' },
};

export async function scrapeInstantGaming(gameName, platform = 'steam') {
  try {
    const { data } = await axios.get(
`${BASE_URL}/es/igapi/search/?q=${encodeURIComponent(gameName)}`,      { headers: HEADERS, timeout: 15000 }
    );

    const items = data?.results || data?.items || data?.games || [];
    console.log(`    [IG] ${items.length} productos encontrados`);

    const result = findBestMatch(items, gameName, platform);
    if (result) return { ...result, _source: 'real' };

  } catch (err) {
    console.error('    [IG] Error API:', err.message);
  }

  // Fallback demo
  const key = Object.keys(DEMO_PRICES).find(k =>
    gameName.toLowerCase().split(' ').filter(w => w.length > 3).some(w => k.includes(w))
  );
  if (key) {
    console.log(`    [IG] ⚠️  Sin resultado real — usando precio de referencia (${DEMO_PRICES[key].price}€)`);
    return { ...DEMO_PRICES[key], stock: 'ok', type: 'code', _source: 'demo' };
  }

  return null;
}

function findBestMatch(items, gameName, platform) {
  if (!items?.length) return null;
  const nameWords = gameName.toLowerCase().split(' ').filter(w => w.length > 3);

  for (const item of items) {
    const rawName = (item.name || item.title || '').toLowerCase();
    if (!rawName) continue;
    if (nameWords.filter(w => rawName.includes(w)).length < Math.ceil(nameWords.length * 0.6)) continue;
    if (!checkPlatform(rawName + ' ' + (item.platform || '').toLowerCase(), platform)) continue;

    const price = item.price || item.bestPrice || item.min_price;
    if (!price) continue;

    return {
      price: Math.round(parseFloat(price) * 100) / 100,
      region: 'Europa',
      stock: 'ok',
      type: 'code',
    };
  }
  return null;
}

function checkPlatform(text, platform) {
  switch (platform) {
    case 'steam':  return text.includes('steam') || text.includes('pc') || (!text.includes('playstation') && !text.includes('xbox') && !text.includes('nintendo'));
    case 'ps5':    return text.includes('ps5') || text.includes('playstation 5');
    case 'ps4':    return text.includes('ps4') || text.includes('playstation 4');
    case 'xbox':   return text.includes('xbox');
    case 'switch': return text.includes('switch') || text.includes('nintendo');
    default:       return true;
  }
}